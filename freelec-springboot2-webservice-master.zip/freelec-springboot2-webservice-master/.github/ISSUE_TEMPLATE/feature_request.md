---
name: 질문
about: 책 내용에 대해 궁금한게 있으시면 질문주세요
title: "[질문] p.몇페이지"
labels: 질문
assignees: jojoldu

---

기존에 올라온 질문이 아닌지 먼저 검색해주세요!

## 가장 자주 나온 제보

* [P.105 @PutMapping("/api/v1/posts")](https://github.com/jojoldu/freelec-springboot2-webservice/issues/6)
* [P.111 Posts.update](https://github.com/jojoldu/freelec-springboot2-webservice/issues/15)

### 질문

궁금한 내용이 있으시면 해당 부분에 대한 캡쳐 혹은 상세하게 질문을 남겨주세요.  
**실습 오류는 실습 오류 템플릿을 선택해주세요**

