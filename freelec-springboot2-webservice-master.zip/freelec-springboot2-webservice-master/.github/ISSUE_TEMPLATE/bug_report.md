---
name: 오타 제보
about: 오타 발견시 작성해주세요.
title: "[오타 제보] p.몇페이지"
labels: 5쇄반영, 오타
assignees: jojoldu

---

기존에 올라온 제보가 아닌지 먼저 검색해주세요!

## 가장 자주 나온 제보

* [P.105 @PutMapping("/api/v1/posts")](https://github.com/jojoldu/freelec-springboot2-webservice/issues/6)
* [P.111 Posts.update](https://github.com/jojoldu/freelec-springboot2-webservice/issues/15)

### 오타

* as-is (오타):

* to-be (교정):

